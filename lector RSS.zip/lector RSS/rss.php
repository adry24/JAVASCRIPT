<?php
// Cabecera para indicar que vamos a enviar datos JSON y que no haga caché de los datos.
header('Cache-Control: no-cache, must-revalidate');
header('Content-type: application/json');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');

/* 	Utilizar el fichero dbcreacion.sql incluído en la carpeta para crear la base de datos, usuario y tabla en tu servidor MySQL.
Si fuera necesario modifica los datos de la configuración y adáptalos a tu entorno de trabajo. */
	
// Configuración BASE DE DATOS MYSQL
$servidor = "localhost:3307";
$basedatos = "ajax";
$usuario = "tutorial";	
$password = "supersecretpassword";

// Creamos la conexión al servidor.
$conexion = new mysqli($servidor, $usuario, $password, $basedatos);

if ($conexion -> connect_error){
	die("Fallo de conexión: " . $conexion -> connect_error);
}

$conexion -> set_charset("utf8");
	
switch ($_GET['accion']){

	case 'nueva':
		$titulo = $conexion -> real_escape_string($_GET['titulo']);
		$valor = $conexion -> real_escape_string($_GET['valor']);

		$sql = "INSERT INTO rss(titulo, valor) VALUES ('$titulo', '$valor')";
		if ($conexion -> query($sql)){
			echo $conexion -> insert_id;
		} else {
			die("Error de insercción: " . $conexion -> error);
		}
	break;

	case 'borrar':
		$id = $conexion -> real_escape_string($_GET['id']);
		$sql = "DELETE FROM rss WHERE id = '$id'";
		if ($conexion -> query($sql)){
			echo "Borrado con exito";
		} else {
			die("Borrado erroneo: " . $conexion -> error);
		}
	break;
	
	case 'cargar':
		$id = $conexion -> real_escape_string($_GET['id']);
		$sql = "SELECT * FROM rss WHERE id = '$id'";
		$resultados = $conexion -> query($sql);

		if ($resultados -> num_rows > 0){
			$registros = $resultados -> fetch_assoc();
			$url = $registros['valor'];

			$xmlContent = file_get_contents($url);
			if($xmlContent === FALSE){
				echo json_encode(["Error" => "Carga de archivo XML desde la URL: " . $url]);
				exit;
			}
			$doc = new DOMDocument();
			//@$doc -> loadXML($xmlContent);

			if(/*$doc === false*/ !$doc -> loadXML($xmlContent)){
				echo json_encode(["Error" => "Fallo al procesar el archivo XML."]);
				exit;
			}

			$arrFeeds = array();
			foreach ($doc -> getElementsByTagName('item') as $node){
				if ($node instanceof DOMElement){

					$titulo = $node -> getElementsByTagName('title') -> item(0) -> nodeValue ?? 'Fallo al cargar título';
					$descripcion = $node -> getElementsByTagName('description') -> item(0) -> nodeValue ?? 'Sin descripcion';
					$url = $node -> getElementsByTagName('link') -> item(0) -> nodeValue ?? 'URL oculta';
					$fecha = $node -> getElementsByTagName('pubDate') -> item(0) -> nodeValue ?? '--/--/----';
					
					$arrFeeds[] = array(
						'titulo' => $titulo,
						'descripcion' => $descripcion,
						'url' => $url,
						'fecha' => $fecha
					);
				}
			}
			echo json_encode($arrFeeds);
		} else {
			echo json_encode(["Error" => "No se encontró el RSS con el ID especificado."]);
		}
	break;

	case 'recursosRSS':
		$sql = "SELECT *FROM rss";
		$resultados = $conexion -> query($sql);
		$rssArray = array();
		while ($row = $resultados -> fetch_assoc()){
			$rssArray[$row['id']] = array('titulo' => $row['titulo']);
		}

		echo json_encode($rssArray);
	break;
}
?>